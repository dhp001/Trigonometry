public class Tangent{
  //Master Object
  public void TAN(double DEG){
    System.out.println(tan(DEG));
  }
  //Slave Object
  public float tan(double DEG){
    return (float) (new Sine().sin(DEG)/new Cosine().cos(DEG));
  }

  //Master Object
  public void COT(double DEG){
    System.out.println(cot(DEG));
  }
  //Slave Object
  public float cot(double DEG){
    return (float) (new Cosine().cos(DEG)/new Sine().sin(DEG));
  }
}