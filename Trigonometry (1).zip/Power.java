public class Power {
  
  public double pwr(double v, int p)
    {
    double V = 1;
    //calculate power through recursive step
    for (int i = 1;i <= p;++i)
    {
        V = V * v;
    }
    return (V);
   }
   public void PWR(double v, int p)
   {
    System.out.println(pwr(v,p));
  }
}