public class absValue{
  public double abs(double x)
  {
    if(x<0) return -x;
    else return x;
  }
}