public class Power {
  
  public float pwr(double v, int p)
    {
    float V = 1;
    //calculate power through recursive step
    for (int i = 1;i <= p;++i)
    {
        V = V * (float)v;
    }
    return (V);
   }
   public void PWR(double v, int p)
   {
    System.out.println(pwr(v,p));
  }
}