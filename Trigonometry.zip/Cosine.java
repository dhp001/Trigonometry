public class Cosine{
  //Slave Object
  public double cos(double DEG){
    
    //Declaration of Variables
    double pres=0.000001;
    double cos=1;
    int j=2;
    int max = 55;

    Power PowerObject = new Power();
    factorial factorialObject = new factorial();

    //Use Periodic Nature of Cosine to reduce angle to 
    //angle represented in the unit circle
    while(DEG>(2*Main.PI))
      {
        DEG=DEG-(2*Math.PI);
      }
    
    //Taylor Series Expansion
    for (int i =2; i<=max; i=i+2){
      if(j%2==0) {
        cos=cos-PowerObject.pwr(DEG,i)/factorialObject.fact(i);
      }
      else{
        cos=cos+PowerObject.pwr(DEG,i)/factorialObject.fact(i);
      }
      j++;
    }
    //Taylor series tends to return 0.00000001 for 0,
    //manually correct this issue
    if(cos<=pres) return 0;
    else return cos;
  }
  //Master Object
  public void COS(double DEG)
  {
    System.out.println(cos(DEG));
  }
  //Slave Object
  public double sec(double DEG){
    return (1/cos(DEG));
  }
  //Master Object
  public void SEC(double DEG){
    System.out.println(sec(DEG));
  }
}