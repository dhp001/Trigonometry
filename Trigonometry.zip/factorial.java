public class factorial{
  public long fact(Integer n){
    //Base case
    if(n<=1) {
      return 1;
    }
    //recurse step
    else {
      return (n*fact(n-1));
    }
  }
  public void FACT(Integer n){
    System.out.println(fact(n));
  }
}