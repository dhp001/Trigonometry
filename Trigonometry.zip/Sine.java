public class Sine{
  //Slave Object
  public double sin(double DEG){

    //Declaration of variables
    int j=2;
    int max = 55;
    double sin;
    Power PowerObject = new Power();
    factorial factorialObject = new factorial();

    //Use periodic nature of sine to reduce angle to usable angle
    while(DEG>(2*Main.PI))
      {
        DEG=DEG-(2*Main.PI);
      }
    
    sin = DEG;
    
    //Taylor Series Expansion
    for (int i =3; i<=max; i=i+2){
      if(j%2==0) {
        sin=sin+PowerObject.pwr(DEG,i)/factorialObject.fact(i);
      }
      else{
        sin=sin-PowerObject.pwr(DEG,i)/factorialObject.fact(i);
      }
      j++;
    }
    return sin;
  }
  //Master object
  public void SIN(double DEG)
  {
    System.out.println(sin(DEG));
  }

  //Slave object
  public double csc(double DEG){
    return 1/sin(DEG);
  }
  //Master Object
  public void CSC(double DEG){
    System.out.println(csc(DEG));
  }
}