public class Inverse{
  public double arcsin(double R){
    Sine sineObject = new Sine();
    absValue absValue = new absValue();
        
    double S;
    double pres = 0.0001;
    double arcsin=R;

    if(R==-1) return -Main.PI/2;
    for (double i = (Main.PI / 2);i >= -(Main.PI / 2);i = i - pres)
    {
        S = sineObject.sin(i);
        if (absValue.abs(S - R) < pres)//Seek answer
        {
            return i;
        }
    }
    
    return 0;
  }
  public void ARCSIN(double R){
    System.out.println(arcsin(R));
  }

  public double arccos(double R){
    double c = 0;
    double pres = 0.00000001;
    Cosine cosineObject = new Cosine();
    absValue absValue = new absValue();
    
    //Limit domain
    if(R==1) return 0;
    if(R==-1) return Main.PI;
    for (double i = Main.PI;i >= 0;i = i - pres)//check range
    {
        c = cosineObject.cos(i);
        
        if (R+c < pres)//Seek answer
        {
            return i;
        }
    }
    return 0;
  }
  
  public void ARCCOS(double R){
    System.out.println(arccos(R));
  }

  public double arctan(double R){
    double t = 0;
    double pres = 0.00001;
    double pres2 = 0.000009;//pres2 deals with how sensitive arctan is
    Tangent tanObject = new Tangent();
    absValue absValue = new absValue();

    for (double i = -(Main.PI / 2) + pres2;i <= Main.PI / 2;i = i + pres2)//limit range
    {
        t = tanObject.tan(i);
        if (absValue.abs(R - t) < pres)
        {
            return i;
        }
    }
    return 0;
  }
  
  public void ARCTAN(double R){
    System.out.println(arctan(R));
  }
  
}