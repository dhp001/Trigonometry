/*

Created by Diego Hernandez Parets
COP2800 TR 10:40-12:20
Trigonometry Final Project

*/

import java.util.Scanner;

class Main {
  public static final double PI=3.14159265359;
  public static void main(String[] args) {
    
    //Declaration of method variables
    Sine sineObject = new Sine();
    Cosine cosineObject = new Cosine();
    Tangent tanObject = new Tangent();
    Inverse invObject= new Inverse();
    Scanner input = new Scanner(System.in);
    //Declaration of variables
    int choice;
    double DEG;
    double R;
    Boolean t=true;

    while(t==true);
    {
    //Formatting and presenting a choice
    System.out.printf("\n****************************\n\n");
    System.out.printf("Please pick your choice:\n1 for Sine\n2 for Cosine\n3 for Tangent\n4 for Cosecant\n5 for Secant\n6 for Cotangent\n7 for Arcsine\n8 for Arccosine\n9 for Arctangent\n0 to quit.\n");
    choice= input.nextInt();
    
    switch(choice){ //Carrying out user-selected function
      case 1:
        System.out.printf("Please enter your angle in Radians: ");
        DEG=input.nextDouble();
        sineObject.SIN(DEG);
        break;
      case 2:
        System.out.printf("Please enter your angle in Radians: ");
        DEG=input.nextDouble();
        cosineObject.COS(DEG);
        break;
      case 3:
      System.out.printf("Please enter your angle in Radians: ");
        DEG=input.nextDouble();
        tanObject.TAN(DEG);
        break;
      case 4:
        System.out.printf("Please enter your angle in Radians: ");
        DEG=input.nextDouble();
        sineObject.CSC(DEG);
        break;
      case 5:
        System.out.printf("Please enter your angle in Radians: ");
        DEG=input.nextDouble();
        cosineObject.SEC(DEG);
        break;
      case 6:
        System.out.printf("Please enter your angle in Radians: ");
        DEG=input.nextDouble();
        tanObject.COT(DEG);
        break;
      case 7:
        System.out.printf("Please enter your ratio, R: ");
        R=input.nextDouble();
        //Check validity of value entered
        if(R>1 ^ R<-1){
          System.out.printf("Not a valid selection.\n");
          break;
        }
        invObject.ARCSIN(R);
        break;
      case 8:
        System.out.printf("Please enter your ratio, R: ");
        R=input.nextDouble();
        //Check validity of value entered
        if(R>1 ^ R<-1){
          System.out.printf("Not a valid ratio.\n");
          break;
        }
        invObject.ARCCOS(R);
        break;
      case 9:
        System.out.printf("Please enter your ratio, R: ");
        R=input.nextDouble();
        invObject.ARCTAN(R);
        break;
      case 0:
        t=false;
        System.out.printf("Thank you for using the program.");
        System.out.printf("\n****************************\n\n");
        break;
      default:
        System.out.println("Not valid choice.");
      }
      //Determine if loop should continue or not.
      System.out.println("Would you like to continue? (true for yes, false for no");
      t=input.nextBoolean();
    }
  }
}